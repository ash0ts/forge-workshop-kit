from html import escape

def render_board(rows, title='Departures'):
    heading = '<h2>' + escape(str(title)) + '</h2>'
    notice = '<p>Historical schedule. Data provided by MassDOT / MBTA.</p>'
    if not rows:
        return heading + notice + '<p>No scheduled departures in the next two hours</p>'
    cells = ''.join('<tr><td>' + escape(str(row['stop_name'])) + '</td><td>' +
                    escape(str(row['headsign'])) + '</td><td><time>' +
                    escape(str(row['departure_time'])) + '</time></td></tr>' for row in rows)
    return heading + notice + '<table><thead><tr><th>Platform</th><th>Toward</th><th>Scheduled departure</th></tr></thead><tbody>' + cells + '</tbody></table>'

def render_journey(journey, title='Last direct train'):
    heading = '<h2>' + escape(str(title)) + '</h2>'
    notice = '<p>Historical schedule. Data provided by MassDOT / MBTA.</p>'
    if journey is None:
        return heading + notice + '<p>No direct train in this timetable subset</p>'
    fields = [('From platform', 'origin_stop_id'), ('To platform', 'destination_stop_id'),
              ('Service date', 'service_date'), ('Departs', 'departure_time'), ('Arrives', 'arrival_time')]
    return heading + notice + '<dl>' + ''.join('<dt>' + label + '</dt><dd>' +
        escape(str(journey[key])) + '</dd>' for label, key in fields) + '</dl>'
