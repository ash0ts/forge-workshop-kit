from datetime import date, datetime, timedelta, timezone

TZ = timezone(timedelta(hours=-5))
START, END = date(2024, 11, 28), date(2024, 12, 4)

def active_services(tables, day):
    stamp = day.strftime('%Y%m%d')
    weekday = day.strftime('%A').lower()
    active = {r['service_id'] for r in tables['calendar']
              if r['start_date'] <= stamp <= r['end_date'] and r[weekday] == '1'}
    for row in tables['calendar_dates']:
        if row['date'] == stamp:
            if row['exception_type'] == '1':
                active.add(row['service_id'])
            elif row['exception_type'] == '2':
                active.discard(row['service_id'])
    return active

def departure_at(day, gtfs_time):
    h, m, s = map(int, gtfs_time.split(':'))
    return datetime.combine(day, datetime.min.time(), tzinfo=TZ) + timedelta(hours=h, minutes=m, seconds=s)

def platform(tables, stop_id):
    for row in tables['stops']:
        if row['stop_id'] == stop_id and row['location_type'] == '0':
            return row
    raise ValueError('Choose a platform in the teaching subset.')

def service_day(value):
    day = date.fromisoformat(value)
    if not START <= day <= END:
        raise ValueError('Date outside the historical teaching week.')
    return day

def departures(tables, stop_id, at, limit=5):
    stop = platform(tables, stop_id)
    now = datetime.fromisoformat(at)
    if now.utcoffset() is None:
        raise ValueError('Include the timestamp UTC offset.')
    now = now.astimezone(TZ)
    service_day(now.date().isoformat())
    if type(limit) is not int or not 1 <= limit <= 20:
        raise ValueError('Limit must be 1..20.')
    trips = {r['trip_id']: r for r in tables['trips']}
    result = []
    for shift in (-1, 0, 1):
        day = now.date() + timedelta(days=shift)
        if not START <= day <= END:
            continue
        active = active_services(tables, day)
        for row in tables['stop_times']:
            trip = trips[row['trip_id']]
            if row['stop_id'] != stop_id or row['pickup_type'] == '1' or trip['service_id'] not in active:
                continue
            departure = departure_at(day, row['departure_time'])
            if now <= departure <= now + timedelta(hours=2):
                result.append(dict(trip_id=trip['trip_id'], route_id=trip['route_id'],
                    headsign=trip['trip_headsign'], stop_id=stop_id, stop_name=stop['stop_name'],
                    service_date=day.isoformat(), departure_time=departure.isoformat()))
    return sorted(result, key=lambda r: (r['departure_time'], r['trip_id']))[:limit]

def last_departure(tables, origin_id, destination_id, service_date):
    day = service_day(service_date)
    platform(tables, origin_id)
    platform(tables, destination_id)
    if origin_id == destination_id:
        return None
    active = active_services(tables, day)
    rows_by_trip = {}
    for row in tables['stop_times']:
        rows_by_trip.setdefault(row['trip_id'], []).append(row)
    result = []
    for trip in tables['trips']:
        if trip['service_id'] not in active:
            continue
        rows = sorted(rows_by_trip.get(trip['trip_id'], []), key=lambda r: int(r['stop_sequence']))
        origin = None
        for row in rows:
            if row['stop_id'] == origin_id and row['pickup_type'] != '1':
                origin = row
            if origin and row['stop_id'] == destination_id and row['drop_off_type'] != '1' and int(row['stop_sequence']) > int(origin['stop_sequence']):
                result.append(dict(trip_id=trip['trip_id'], route_id=trip['route_id'],
                    headsign=trip['trip_headsign'], origin_stop_id=origin_id,
                    destination_stop_id=destination_id, service_date=service_date,
                    departure_time=departure_at(day, origin['departure_time']).isoformat(),
                    arrival_time=departure_at(day, row['arrival_time']).isoformat()))
                break
    return max(result, key=lambda r: (r['departure_time'], r['trip_id'])) if result else None
