# Prepared transit reference app

Instructor-authored worked implementation, not an agent-generated result.

Historical MBTA schedule, November 28–December 4, 2024. Not live transit advice.

Run `uv run --with marimo marimo edit app.py` from this directory.
The app uses local data and no model calls. All 18 reference scenarios pass.
