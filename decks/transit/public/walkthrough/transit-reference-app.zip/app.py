# /// script
# requires-python = ">=3.11"
# dependencies = ["marimo==0.25.2"]
# ///
import marimo
__generated_with = "0.25.2"
app = marimo.App(width="medium")

@app.cell
def _():
    import marimo as mo
    import gzip, json
    from pathlib import Path
    import query, presentation
    tables = json.loads(gzip.decompress((Path(__file__).parent / 'tables.json.gz').read_bytes()))
    return mo, tables, query, presentation

@app.cell
def _(mo, tables):
    _intro = mo.md("# The last train is still on yesterday’s timetable\nHistorical schedule data from MassDOT / MBTA, November 28 to December 4, 2024. Choose a platform and a time to see departures during the next two hours. This teaching app does not show live arrivals.")
    _style = mo.Html("<style>table{border-collapse:collapse;width:100%}th,td{padding:12px 16px;text-align:left;border-bottom:1px solid #8885}th{font-weight:650}dt{margin-top:12px;font-weight:650}dd{margin:4px 0 12px}table time{white-space:nowrap}</style>")
    platforms = {r['stop_name'] + ' / ' + r.get('platform_name', '') + ' (' + r['stop_id'] + ')': r['stop_id'] for r in tables['stops'] if r['location_type'] == '0'}
    stop = mo.ui.dropdown(platforms, value=next(k for k,v in platforms.items() if v == '70076'), label='Departure platform')
    route = mo.ui.dropdown(['All routes in this subset', 'Red'], value='Red', label='Route')
    at = mo.ui.text(value='2024-11-29T00:00:00-05:00', label='Historical date and time, including UTC offset', full_width=True)
    mo.vstack([_intro, _style, route, stop, at])
    return stop, at, platforms, route

@app.cell
def _(mo, tables, query, presentation, stop, at, route):
    try:
        rows = query.departures(tables, stop.value, at.value)
        rows = [r for r in rows if route.value != 'Red' or r['route_id'] == route.value]
        mo.output.append(mo.Html(presentation.render_board(rows)))
    except (ValueError, KeyError, TypeError) as _error:
        mo.output.append(mo.callout(mo.md('Check the selected platform and date. Use an ISO timestamp such as `2024-11-29T00:00:00-05:00`. '+str(_error)), kind='warn'))
    return

@app.cell
def _(mo, platforms):
    origin = mo.ui.dropdown(platforms, value=next(k for k,v in platforms.items() if v == '70080'), label='From platform')
    destination = mo.ui.dropdown(platforms, value=next(k for k,v in platforms.items() if v == '70072'), label='To platform')
    service_date = mo.ui.text(value='2024-11-28', label='Service date, YYYY-MM-DD', full_width=True)
    mo.vstack([mo.md('## Last direct train on this service date\nChoose platforms in the same direction. This example finds a direct journey; it does not plan transfers.'), origin, destination, service_date])
    return origin, destination, service_date

@app.cell
def _(mo, tables, query, presentation, origin, destination, service_date):
    import json as _json
    try:
        journey = query.last_departure(tables, origin.value, destination.value, service_date.value)
        mo.output.append(mo.vstack([mo.Html(presentation.render_journey(journey)),
                   mo.download(_json.dumps(journey, indent=2).encode(), filename='last-direct-train.json', label='Download this itinerary')]))
    except (ValueError, KeyError, TypeError) as _error:
        mo.output.append(mo.callout(mo.md('Check the platforms and service date. Use a date from 2024-11-28 through 2024-12-04. '+str(_error)), kind='warn'))
    return

if __name__ == '__main__':
    app.run()
